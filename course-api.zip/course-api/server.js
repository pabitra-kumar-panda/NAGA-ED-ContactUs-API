const express = require('express');
const app = express();
const port = 3000;

// Root route
app.get('/', (req, res) => {
    res.send('Welcome to the Course API');
});

// Middleware to parse JSON bodies
app.use(express.json());

// Placeholder for the courses data
let courses = [];



//Create
app.post('/courses', (req, res) => {
    const newCourse = {
        id: courses.length + 1,  // Assign an auto-incremented ID
        title: req.body.title,
        description: req.body.description,
        duration: req.body.duration
    };
    courses.push(newCourse);  
    res.status(201).json(newCourse);  
});

//Read
app.get('/courses', (req, res) => {
    res.json(courses);  
});

//Update
app.put('/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);  
    const courseIndex = courses.findIndex(course => course.id === courseId);  
    if (courseIndex !== -1) {
       
        courses[courseIndex].title = req.body.title;
        courses[courseIndex].description = req.body.description;
        courses[courseIndex].duration = req.body.duration;

        res.json(courses[courseIndex]);  // Respond with the updated course
    } else {
        res.status(404).json({ message: 'Course not found' });  
    }
});

//Delete
app.delete('/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    const courseIndex = courses.findIndex(course => course.id === courseId);

    if (courseIndex !== -1) {
        courses.splice(courseIndex, 1);  
        res.status(204).send();  
    } else {
        res.status(404).json({ message: 'Course not found' });
    }
});

//Start the server
app.listen(port, () => {
    console.log(`Course API running at http://localhost:${port}`);
});
